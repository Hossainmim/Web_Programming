document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("registrationForm");
    const dobInput = document.getElementById("dob");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const textInputs = [document.getElementById("address"), document.getElementById("allergies"), document.getElementById("diseaseHistory")];

    form.addEventListener("submit", function(event) {
        // Check age from DOB
        if (!isValidAge(dobInput.value)) {
            alert("You must be at least 18 years old to register.");
            event.preventDefault(); // Stop form submission
            return; // Exit the function if not valid
        }

        // Password match check
        validatePasswords(event);

        // Text input validation for offensive words
        textInputs.forEach(input => {
            if (containsOffensiveWords(input.value)) {
                alert("Please remove any offensive words from your entries.");
                event.preventDefault();
            }
        });

        if (!event.defaultPrevented) {
            alert("Registration successful!");
        }
    });
});

function isValidAge(dob) {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--; // Adjust age if current month/day is before the birth month/day
    }
    return age >= 18;
}

function containsOffensiveWords(text) {
    const offensiveWords = ["stupid", "fool"]; // Add more words as needed
    return offensiveWords.some(word => text.includes(word));
}
function validatePasswords(event) {
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    if (password.value !== confirmPassword.value) {
        alert("Passwords do not match.");
        event.preventDefault();
    }
}

function togglePasswordVisibility(inputId) {
    var input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        event.target.textContent = "Hide";
    } else {
        input.type = "password";
        event.target.textContent = "Show";
    }
}
