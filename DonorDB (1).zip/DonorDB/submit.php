<?php
include 'db.php'; // Include your DB connection script

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    
    $nid = $conn->real_escape_string($_POST['nid']);
    $dob = $conn->real_escape_string($_POST['dob']);

     //check nid and dob exist or not 

     $checkQuery = "SELECT * FROM Donors WHERE nid = '$nid' AND dob = '$dob'";
     $checkResult = $conn->query($checkQuery);
 
     if ($checkResult->num_rows > 0) {
         header('Location: page2.html'); // Adjust 'page2.php' as needed
         exit;
     }

    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $contact_number = $conn->real_escape_string($_POST['contact']);
    $address = $conn->real_escape_string($_POST['address']);
    $blood_type = $conn->real_escape_string($_POST['blood_type']);
    $height = $conn->real_escape_string($_POST['height']);
    $weight = $conn->real_escape_string($_POST['weight']);
    $donated_before = isset($_POST['donatedBefore']) ? 1 : 0; // Assuming checkbox for donation
    $allergy_details = $conn->real_escape_string($_POST['allergies']);
    $disease_history = $conn->real_escape_string($_POST['diseaseHistory']);
    $has_anemia = isset($_POST['hasAnemia']) ? 1 : 0;
    $is_cardiac_patient = isset($_POST['cardiacPatient']) ? 1 : 0;
    $under_medication = isset($_POST['underMedication']) ? 1 : 0;
    $password = $conn->real_escape_string($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hashing the password before storing it

   

    // SQL to insert data into the donors table
    $sql = "INSERT INTO Donors (name, nid, dob, email, gender, contact_number, address, blood_type, height, weight, donated_before, allergy_details, disease_history, has_anemia, is_cardiac_patient, under_medication, password)
            VALUES ('$name', '$nid', '$dob', '$email', '$gender', '$contact_number', '$address', '$blood_type', $height, $weight, $donated_before, '$allergy_details', '$disease_history', $has_anemia, $is_cardiac_patient, $under_medication, '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully.";
        echo "<img src='cong.png' alt='Congratulations' />";
        echo "<a href='index.html'>Click here to return to the home page.</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
