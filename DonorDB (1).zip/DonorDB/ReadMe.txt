1. Create a database using xampp/mysql.

2. Database name DonorDB.
code: CREATE DATABASE DonorDB;

3. Create Table Donors
code: 

CREATE TABLE Donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    nid VARCHAR(20) NOT NULL UNIQUE,
    dob DATE NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    gender ENUM('male', 'female', 'other') NOT NULL,
    contact_number VARCHAR(15) NOT NULL,
    address VARCHAR(255),
    blood_type ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
    height DECIMAL(5, 2),
    weight DECIMAL(5, 2),
    donated_before BOOLEAN,
    allergy_details TEXT,
    disease_history TEXT,
    has_anemia BOOLEAN,
    is_cardiac_patient BOOLEAN,
    under_medication BOOLEAN,
    password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


Rest of the file will work as per the lab instruction. 
